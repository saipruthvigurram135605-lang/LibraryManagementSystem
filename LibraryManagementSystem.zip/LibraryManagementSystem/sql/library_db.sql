-- =====================================================
-- Library Management System - single setup script
-- XAMPP: phpMyAdmin -> Import  (or: mysql -u root < library_db.sql)
-- =====================================================
DROP DATABASE IF EXISTS library_db;
CREATE DATABASE library_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE library_db;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(64) NOT NULL,              -- SHA-256 hash
  full_name VARCHAR(100) NOT NULL,
  role ENUM('ADMIN','LIBRARIAN') NOT NULL DEFAULT 'LIBRARIAN'
) ENGINE=InnoDB;

CREATE TABLE books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  isbn VARCHAR(20) NOT NULL UNIQUE,
  title VARCHAR(200) NOT NULL,
  author VARCHAR(120) NOT NULL,
  category VARCHAR(60) NOT NULL,
  publisher VARCHAR(120),
  total_copies INT NOT NULL DEFAULT 1,
  available_copies INT NOT NULL DEFAULT 1,
  added_on DATE NOT NULL DEFAULT (CURRENT_DATE),
  CHECK (total_copies >= 0 AND available_copies >= 0 AND available_copies <= total_copies)
) ENGINE=InnoDB;

CREATE TABLE members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  member_code VARCHAR(20) UNIQUE,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  phone VARCHAR(15) NOT NULL,
  address VARCHAR(255),
  joined_date DATE NOT NULL DEFAULT (CURRENT_DATE),
  status ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE'
) ENGINE=InnoDB;

CREATE TABLE issues (
  id INT AUTO_INCREMENT PRIMARY KEY,
  book_id INT NOT NULL,
  member_id INT NOT NULL,
  issue_date DATE NOT NULL,
  due_date DATE NOT NULL,
  return_date DATE NULL,
  fine DECIMAL(8,2) NOT NULL DEFAULT 0,
  status ENUM('ISSUED','RETURNED') NOT NULL DEFAULT 'ISSUED',
  CONSTRAINT fk_issue_book   FOREIGN KEY (book_id)   REFERENCES books(id),
  CONSTRAINT fk_issue_member FOREIGN KEY (member_id) REFERENCES members(id)
) ENGINE=InnoDB;

-- ---------- Sample data ----------
-- Logins: admin / admin123    librarian / lib123
INSERT INTO users (username,password,full_name,role) VALUES
('admin',     SHA2('admin123',256), 'System Administrator', 'ADMIN'),
('librarian', SHA2('lib123',256),   'Head Librarian',       'LIBRARIAN');

INSERT INTO books (isbn,title,author,category,publisher,total_copies,available_copies) VALUES
('9780132350884','Clean Code','Robert C. Martin','Programming','Prentice Hall',5,5),
('9780134685991','Effective Java','Joshua Bloch','Programming','Addison-Wesley',4,4),
('9781491950296','Head First Servlets and JSP','Bryan Basham','Programming','O''Reilly',3,3),
('9780262033848','Introduction to Algorithms','Thomas H. Cormen','Computer Science','MIT Press',3,3),
('9780073523323','Database System Concepts','Abraham Silberschatz','Database','McGraw-Hill',4,4),
('9780140449266','The Count of Monte Cristo','Alexandre Dumas','Fiction','Penguin',2,2),
('9780143039433','The Guide','R. K. Narayan','Fiction','Penguin India',2,2),
('9788129135728','Wings of Fire','A. P. J. Abdul Kalam','Biography','Universities Press',3,3);

INSERT INTO members (member_code,name,email,phone,address) VALUES
('LIB0001','Rahul Sharma','rahul@example.com','9876543210','Gandhidham, Gujarat'),
('LIB0002','Priya Patel','priya@example.com','9876501234','Bhuj, Gujarat'),
('LIB0003','Amit Mehta','amit@example.com','9988776655','Anjar, Gujarat');
