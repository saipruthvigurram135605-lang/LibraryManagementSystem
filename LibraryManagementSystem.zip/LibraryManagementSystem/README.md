# Library Management System

A web-based Library Management System built with **Java Servlets, JSP, JSTL/EL, JDBC and MySQL** (MVC + DAO pattern).

## Problem Statement
Manual library record keeping is slow and error-prone: books are lost track of, due dates are missed and fines are calculated by hand.
This project digitises the workflow so a librarian can manage the catalogue, register members, issue/return books and automatically calculate late fines.

## Functional Requirements
1. Staff login/logout with session management (roles: ADMIN, LIBRARIAN)
2. Dashboard with live statistics (titles, copies, available, members, issued, overdue)
3. Book management: add, view, search, edit, delete (CRUD)
4. Member management: register, view, search, edit, delete (CRUD)
5. Issue a book (stock check, active-member check, max 3 books per member, 1-30 day loan)
6. Return a book (stock restored, fine = Rs. 5 x overdue days)
7. Issue history with filters (Currently Issued / Returned / All)
8. Client-side (JavaScript) and server-side form validation
9. Exception handling for duplicate ISBN/email, delete restrictions, DB errors

## Technology
| Layer | Technology |
|---|---|
| View | JSP, JSTL (core + fmt), EL, HTML/CSS, JavaScript |
| Controller | Servlets, Filter (`AuthFilter`), HttpSession |
| Model / DAO | Plain JDBC (`PreparedStatement`, transactions) |
| Database | MySQL / MariaDB (XAMPP) |
| Build / Server | Maven (WAR), Apache Tomcat 9 |

## Database (4 tables)
`users`, `books`, `members`, `issues` (FK: issues.book_id -> books.id, issues.member_id -> members.id). See `sql/library_db.sql`.

## Setup (XAMPP + Tomcat 9)
1. Start **MySQL** in XAMPP Control Panel (only MySQL is needed; Apache is not required).
2. Open `http://localhost/phpmyadmin` -> **Import** -> choose `sql/library_db.sql` -> **Go**.
   (This creates the `library_db` database, all tables and sample data in one step.)
3. If your MySQL root has a password, edit `src/main/java/com/library/util/DBConnection.java`.
4. Build: `mvn clean package` -> produces `target/LibraryManagementSystem.war`.
5. Copy the WAR into Tomcat 9's `webapps/` folder and start Tomcat (**use Tomcat 9, not 10** - this project uses `javax.servlet`).
6. Open `http://localhost:8080/LibraryManagementSystem/`

### Run from an IDE
Eclipse (Enterprise Java) / IntelliJ Ultimate / NetBeans: import as an existing **Maven** project, add a Tomcat 9 server, run on server.

## Demo Logins
| Username | Password | Role |
|---|---|---|
| admin | admin123 | ADMIN |
| librarian | lib123 | LIBRARIAN |

## Project Structure
```
sql/library_db.sql                 -> database + sample data
src/main/java/com/library/
   util/    DBConnection, PasswordUtil (SHA-256), LibraryException
   model/   User, Book, Member, IssueRecord
   dao/     UserDAO, BookDAO, MemberDAO, IssueDAO
   filter/  AuthFilter  (session check)
   servlet/ Login, Logout, Dashboard, Book, Member, Issue servlets
src/main/webapp/
   login.jsp, index.jsp, css/style.css
   WEB-INF/views/  dashboard, books, book-form, members, member-form, issues, error, header/footer fragments
```

## Deployment (final submission)
The app needs Java + MySQL hosting. Easy options: a Docker image on Render/Railway (Tomcat 9 base image + a managed MySQL),
or any VPS with Tomcat. Update the DB URL/user/password in `DBConnection.java` to the hosted database before building.
