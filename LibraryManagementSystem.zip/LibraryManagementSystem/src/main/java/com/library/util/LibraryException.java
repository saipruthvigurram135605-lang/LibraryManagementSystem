package com.library.util;

/** Business-rule violation (e.g. no copies available). Message is shown to the user. */
public class LibraryException extends Exception {
    public LibraryException(String message) { super(message); }
}
