package com.library.servlet;

import com.library.dao.BookDAO;
import com.library.model.Book;
import com.library.util.LibraryException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/books")
public class BookServlet extends HttpServlet {
    private final BookDAO dao = new BookDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("new".equals(action)) {
                req.getRequestDispatcher("/WEB-INF/views/book-form.jsp").forward(req, resp);
            } else if ("edit".equals(action)) {
                Book b = dao.findById(Integer.parseInt(req.getParameter("id")));
                if (b == null) { flash(req, "err", "Book not found."); resp.sendRedirect("books"); return; }
                req.setAttribute("book", b);
                req.getRequestDispatcher("/WEB-INF/views/book-form.jsp").forward(req, resp);
            } else {
                String q = req.getParameter("q");
                req.setAttribute("q", q == null ? "" : q);
                req.setAttribute("books", dao.findAll(q));
                req.getRequestDispatcher("/WEB-INF/views/books.jsp").forward(req, resp);
            }
        } catch (SQLException | NumberFormatException e) {
            req.setAttribute("error", "Error: " + e.getMessage());
            req.getRequestDispatcher("/WEB-INF/views/books.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("delete".equals(action)) {
                dao.delete(Integer.parseInt(req.getParameter("id")));
                flash(req, "msg", "Book deleted successfully.");
                resp.sendRedirect("books");
                return;
            }
            // ---- save (add / update) with server-side validation ----
            Book b = new Book();
            String idStr = req.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) b.setId(Integer.parseInt(idStr));
            b.setIsbn(trim(req.getParameter("isbn")));
            b.setTitle(trim(req.getParameter("title")));
            b.setAuthor(trim(req.getParameter("author")));
            b.setCategory(trim(req.getParameter("category")));
            b.setPublisher(trim(req.getParameter("publisher")));

            String error = null;
            try { b.setTotalCopies(Integer.parseInt(trim(req.getParameter("totalCopies")))); }
            catch (NumberFormatException e) { error = "Total copies must be a number."; }
            if (error == null) {
                if (b.getIsbn().isEmpty() || b.getTitle().isEmpty() || b.getAuthor().isEmpty() || b.getCategory().isEmpty())
                    error = "ISBN, title, author and category are required.";
                else if (!b.getIsbn().matches("[0-9\\-]{10,17}"))
                    error = "ISBN must contain 10 to 17 digits (hyphens allowed).";
                else if (b.getTotalCopies() < 1 || b.getTotalCopies() > 999)
                    error = "Total copies must be between 1 and 999.";
            }
            if (error != null) {
                req.setAttribute("error", error);
                req.setAttribute("book", b);
                req.getRequestDispatcher("/WEB-INF/views/book-form.jsp").forward(req, resp);
                return;
            }
            try {
                if (b.getId() == 0) { dao.add(b); flash(req, "msg", "Book added successfully."); }
                else                { dao.update(b); flash(req, "msg", "Book updated successfully."); }
                resp.sendRedirect("books");
            } catch (LibraryException e) {
                req.setAttribute("error", e.getMessage());
                req.setAttribute("book", b);
                req.getRequestDispatcher("/WEB-INF/views/book-form.jsp").forward(req, resp);
            }
        } catch (LibraryException e) {
            flash(req, "err", e.getMessage());
            resp.sendRedirect("books");
        } catch (SQLException | NumberFormatException e) {
            flash(req, "err", "Operation failed: " + e.getMessage());
            resp.sendRedirect("books");
        }
    }

    private String trim(String s) { return s == null ? "" : s.trim(); }
    private void flash(HttpServletRequest req, String key, String text) { req.getSession().setAttribute(key, text); }
}
