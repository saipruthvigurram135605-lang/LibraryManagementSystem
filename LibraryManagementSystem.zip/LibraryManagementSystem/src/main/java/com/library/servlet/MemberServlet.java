package com.library.servlet;

import com.library.dao.MemberDAO;
import com.library.model.Member;
import com.library.util.LibraryException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/members")
public class MemberServlet extends HttpServlet {
    private final MemberDAO dao = new MemberDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("new".equals(action)) {
                req.getRequestDispatcher("/WEB-INF/views/member-form.jsp").forward(req, resp);
            } else if ("edit".equals(action)) {
                Member m = dao.findById(Integer.parseInt(req.getParameter("id")));
                if (m == null) { flash(req, "err", "Member not found."); resp.sendRedirect("members"); return; }
                req.setAttribute("member", m);
                req.getRequestDispatcher("/WEB-INF/views/member-form.jsp").forward(req, resp);
            } else {
                String q = req.getParameter("q");
                req.setAttribute("q", q == null ? "" : q);
                req.setAttribute("members", dao.findAll(q));
                req.getRequestDispatcher("/WEB-INF/views/members.jsp").forward(req, resp);
            }
        } catch (SQLException | NumberFormatException e) {
            req.setAttribute("error", "Error: " + e.getMessage());
            req.getRequestDispatcher("/WEB-INF/views/members.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("delete".equals(action)) {
                dao.delete(Integer.parseInt(req.getParameter("id")));
                flash(req, "msg", "Member deleted successfully.");
                resp.sendRedirect("members");
                return;
            }
            Member m = new Member();
            String idStr = req.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) m.setId(Integer.parseInt(idStr));
            m.setName(trim(req.getParameter("name")));
            m.setEmail(trim(req.getParameter("email")));
            m.setPhone(trim(req.getParameter("phone")));
            m.setAddress(trim(req.getParameter("address")));
            m.setStatus("INACTIVE".equals(req.getParameter("status")) ? "INACTIVE" : "ACTIVE");

            String error = null;
            if (m.getName().isEmpty() || m.getEmail().isEmpty() || m.getPhone().isEmpty())
                error = "Name, email and phone are required.";
            else if (!m.getEmail().matches("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$"))
                error = "Enter a valid email address.";
            else if (!m.getPhone().matches("[0-9]{10}"))
                error = "Phone number must be exactly 10 digits.";

            if (error != null) {
                req.setAttribute("error", error);
                req.setAttribute("member", m);
                req.getRequestDispatcher("/WEB-INF/views/member-form.jsp").forward(req, resp);
                return;
            }
            try {
                if (m.getId() == 0) { dao.add(m); flash(req, "msg", "Member registered successfully."); }
                else                { dao.update(m); flash(req, "msg", "Member updated successfully."); }
                resp.sendRedirect("members");
            } catch (LibraryException e) {
                req.setAttribute("error", e.getMessage());
                req.setAttribute("member", m);
                req.getRequestDispatcher("/WEB-INF/views/member-form.jsp").forward(req, resp);
            }
        } catch (LibraryException e) {
            flash(req, "err", e.getMessage());
            resp.sendRedirect("members");
        } catch (SQLException | NumberFormatException e) {
            flash(req, "err", "Operation failed: " + e.getMessage());
            resp.sendRedirect("members");
        }
    }

    private String trim(String s) { return s == null ? "" : s.trim(); }
    private void flash(HttpServletRequest req, String key, String text) { req.getSession().setAttribute(key, text); }
}
