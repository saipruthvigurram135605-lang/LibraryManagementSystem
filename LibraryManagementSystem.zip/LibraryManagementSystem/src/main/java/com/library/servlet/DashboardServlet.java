package com.library.servlet;

import com.library.dao.IssueDAO;
import com.library.model.IssueRecord;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    private final IssueDAO issueDAO = new IssueDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            req.setAttribute("stats", issueDAO.stats());
            List<IssueRecord> all = issueDAO.findAll("ISSUED");
            req.setAttribute("recent", all.size() > 5 ? all.subList(0, 5) : all);
        } catch (SQLException e) {
            req.setAttribute("error", "Could not load dashboard: " + e.getMessage());
        }
        req.getRequestDispatcher("/WEB-INF/views/dashboard.jsp").forward(req, resp);
    }
}
