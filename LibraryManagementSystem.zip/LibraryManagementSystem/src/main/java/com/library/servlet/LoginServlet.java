package com.library.servlet;

import com.library.dao.UserDAO;
import com.library.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession s = req.getSession(false);
        if (s != null && s.getAttribute("user") != null) {
            resp.sendRedirect(req.getContextPath() + "/dashboard");
            return;
        }
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username") == null ? "" : req.getParameter("username").trim();
        String password = req.getParameter("password") == null ? "" : req.getParameter("password");

        if (username.isEmpty() || password.isEmpty()) {
            fail(req, resp, "Username and password are required.", username);
            return;
        }
        try {
            User user = userDAO.authenticate(username, password);
            if (user == null) {
                fail(req, resp, "Invalid username or password.", username);
                return;
            }
            HttpSession old = req.getSession(false);
            if (old != null) old.invalidate();           // prevent session fixation
            HttpSession session = req.getSession(true);
            session.setAttribute("user", user);
            session.setMaxInactiveInterval(30 * 60);     // 30 minutes
            resp.sendRedirect(req.getContextPath() + "/dashboard");
        } catch (SQLException e) {
            fail(req, resp, "Database error: " + e.getMessage() + " (is MySQL running and library_db imported?)", username);
        }
    }

    private void fail(HttpServletRequest req, HttpServletResponse resp, String msg, String username)
            throws ServletException, IOException {
        req.setAttribute("error", msg);
        req.setAttribute("username", username);
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }
}
