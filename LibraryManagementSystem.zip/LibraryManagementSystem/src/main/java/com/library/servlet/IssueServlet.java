package com.library.servlet;

import com.library.dao.*;
import com.library.util.LibraryException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/issues")
public class IssueServlet extends HttpServlet {
    private final IssueDAO issueDAO = new IssueDAO();
    private final BookDAO bookDAO = new BookDAO();
    private final MemberDAO memberDAO = new MemberDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String status = req.getParameter("status");
        if (status == null) status = "ISSUED";
        try {
            req.setAttribute("status", status);
            req.setAttribute("issues", issueDAO.findAll(status));
            req.setAttribute("books", bookDAO.findAvailable());
            req.setAttribute("members", memberDAO.findActive());
            req.setAttribute("finePerDay", IssueDAO.FINE_PER_DAY);
        } catch (SQLException e) {
            req.setAttribute("error", "Could not load data: " + e.getMessage());
        }
        req.getRequestDispatcher("/WEB-INF/views/issues.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        HttpSession session = req.getSession();
        try {
            if ("issue".equals(action)) {
                int bookId = Integer.parseInt(req.getParameter("bookId"));
                int memberId = Integer.parseInt(req.getParameter("memberId"));
                int days = Integer.parseInt(req.getParameter("days"));
                if (days < 1 || days > 30) throw new LibraryException("Loan period must be between 1 and 30 days.");
                issueDAO.issueBook(bookId, memberId, days);
                session.setAttribute("msg", "Book issued successfully for " + days + " days.");
            } else if ("return".equals(action)) {
                double fine = issueDAO.returnBook(Integer.parseInt(req.getParameter("id")));
                session.setAttribute("msg", fine > 0
                        ? "Book returned. Late fine to collect: Rs. " + (int) fine
                        : "Book returned on time. No fine.");
            }
        } catch (LibraryException e) {
            session.setAttribute("err", e.getMessage());
        } catch (SQLException e) {
            session.setAttribute("err", "Database error: " + e.getMessage());
        } catch (NumberFormatException e) {
            session.setAttribute("err", "Please select a valid book, member and number of days.");
        }
        resp.sendRedirect("issues");
    }
}
