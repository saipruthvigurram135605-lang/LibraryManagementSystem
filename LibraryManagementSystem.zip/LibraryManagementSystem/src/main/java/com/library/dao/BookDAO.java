package com.library.dao;

import com.library.model.Book;
import com.library.util.DBConnection;
import com.library.util.LibraryException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {

    private Book map(ResultSet rs) throws SQLException {
        Book b = new Book();
        b.setId(rs.getInt("id"));
        b.setIsbn(rs.getString("isbn"));
        b.setTitle(rs.getString("title"));
        b.setAuthor(rs.getString("author"));
        b.setCategory(rs.getString("category"));
        b.setPublisher(rs.getString("publisher"));
        b.setTotalCopies(rs.getInt("total_copies"));
        b.setAvailableCopies(rs.getInt("available_copies"));
        return b;
    }

    /** READ (all / search) */
    public List<Book> findAll(String keyword) throws SQLException {
        String sql = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ? OR category LIKE ? ORDER BY title";
        List<Book> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String p = "%" + (keyword == null ? "" : keyword.trim()) + "%";
            for (int i = 1; i <= 4; i++) ps.setString(i, p);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    public List<Book> findAvailable() throws SQLException {
        List<Book> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM books WHERE available_copies > 0 ORDER BY title")) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    /** READ (single) */
    public Book findById(int id) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM books WHERE id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /** CREATE */
    public void add(Book b) throws SQLException, LibraryException {
        String sql = "INSERT INTO books (isbn,title,author,category,publisher,total_copies,available_copies) VALUES (?,?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, b.getIsbn());
            ps.setString(2, b.getTitle());
            ps.setString(3, b.getAuthor());
            ps.setString(4, b.getCategory());
            ps.setString(5, b.getPublisher());
            ps.setInt(6, b.getTotalCopies());
            ps.setInt(7, b.getTotalCopies());
            ps.executeUpdate();
        } catch (SQLIntegrityConstraintViolationException e) {
            throw new LibraryException("A book with ISBN " + b.getIsbn() + " already exists.");
        }
    }

    /** UPDATE - keeps available copies consistent when total copies change */
    public void update(Book b) throws SQLException, LibraryException {
        try (Connection con = DBConnection.getConnection()) {
            int issued;
            try (PreparedStatement ps = con.prepareStatement("SELECT total_copies - available_copies FROM books WHERE id = ?")) {
                ps.setInt(1, b.getId());
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) throw new LibraryException("Book not found.");
                    issued = rs.getInt(1);
                }
            }
            if (b.getTotalCopies() < issued)
                throw new LibraryException("Total copies cannot be less than the " + issued + " copies currently issued.");

            String sql = "UPDATE books SET isbn=?, title=?, author=?, category=?, publisher=?, "
                       + "available_copies = ? - ?, total_copies = ? WHERE id = ?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, b.getIsbn());
                ps.setString(2, b.getTitle());
                ps.setString(3, b.getAuthor());
                ps.setString(4, b.getCategory());
                ps.setString(5, b.getPublisher());
                ps.setInt(6, b.getTotalCopies());
                ps.setInt(7, issued);
                ps.setInt(8, b.getTotalCopies());
                ps.setInt(9, b.getId());
                ps.executeUpdate();
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            throw new LibraryException("A book with ISBN " + b.getIsbn() + " already exists.");
        }
    }

    /** DELETE */
    public void delete(int id) throws SQLException, LibraryException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM books WHERE id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLIntegrityConstraintViolationException e) {
            throw new LibraryException("This book has issue history and cannot be deleted.");
        }
    }
}
