package com.library.dao;

import com.library.model.Member;
import com.library.util.DBConnection;
import com.library.util.LibraryException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO {

    private Member map(ResultSet rs) throws SQLException {
        Member m = new Member();
        m.setId(rs.getInt("id"));
        m.setMemberCode(rs.getString("member_code"));
        m.setName(rs.getString("name"));
        m.setEmail(rs.getString("email"));
        m.setPhone(rs.getString("phone"));
        m.setAddress(rs.getString("address"));
        m.setJoinedDate(rs.getDate("joined_date"));
        m.setStatus(rs.getString("status"));
        return m;
    }

    public List<Member> findAll(String keyword) throws SQLException {
        String sql = "SELECT * FROM members WHERE name LIKE ? OR email LIKE ? OR phone LIKE ? OR member_code LIKE ? ORDER BY name";
        List<Member> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String p = "%" + (keyword == null ? "" : keyword.trim()) + "%";
            for (int i = 1; i <= 4; i++) ps.setString(i, p);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    public List<Member> findActive() throws SQLException {
        List<Member> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM members WHERE status='ACTIVE' ORDER BY name")) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public Member findById(int id) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM members WHERE id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public void add(Member m) throws SQLException, LibraryException {
        String sql = "INSERT INTO members (name,email,phone,address,status) VALUES (?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, m.getName());
            ps.setString(2, m.getEmail());
            ps.setString(3, m.getPhone());
            ps.setString(4, m.getAddress());
            ps.setString(5, m.getStatus());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    try (PreparedStatement up = con.prepareStatement(
                            "UPDATE members SET member_code = CONCAT('LIB', LPAD(id,4,'0')) WHERE id = ?")) {
                        up.setInt(1, keys.getInt(1));
                        up.executeUpdate();
                    }
                }
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            throw new LibraryException("A member with email " + m.getEmail() + " already exists.");
        }
    }

    public void update(Member m) throws SQLException, LibraryException {
        String sql = "UPDATE members SET name=?, email=?, phone=?, address=?, status=? WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getName());
            ps.setString(2, m.getEmail());
            ps.setString(3, m.getPhone());
            ps.setString(4, m.getAddress());
            ps.setString(5, m.getStatus());
            ps.setInt(6, m.getId());
            ps.executeUpdate();
        } catch (SQLIntegrityConstraintViolationException e) {
            throw new LibraryException("A member with email " + m.getEmail() + " already exists.");
        }
    }

    public void delete(int id) throws SQLException, LibraryException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM members WHERE id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLIntegrityConstraintViolationException e) {
            throw new LibraryException("This member has issue history and cannot be deleted. Mark as INACTIVE instead.");
        }
    }
}
