package com.library.dao;

import com.library.model.User;
import com.library.util.DBConnection;
import com.library.util.PasswordUtil;

import java.sql.*;

public class UserDAO {
    /** Returns the user if credentials are valid, otherwise null. */
    public User authenticate(String username, String password) throws SQLException {
        String sql = "SELECT id, username, full_name, role FROM users WHERE username = ? AND password = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, PasswordUtil.sha256(password));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User u = new User();
                    u.setId(rs.getInt("id"));
                    u.setUsername(rs.getString("username"));
                    u.setFullName(rs.getString("full_name"));
                    u.setRole(rs.getString("role"));
                    return u;
                }
            }
        }
        return null;
    }
}
