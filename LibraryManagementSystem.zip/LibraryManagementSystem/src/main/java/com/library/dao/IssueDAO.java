package com.library.dao;

import com.library.model.IssueRecord;
import com.library.util.DBConnection;
import com.library.util.LibraryException;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class IssueDAO {
    public static final int FINE_PER_DAY = 5;      // Rs. per overdue day
    public static final int MAX_BOOKS_PER_MEMBER = 3;

    /** status = "ISSUED", "RETURNED" or anything else for all records */
    public List<IssueRecord> findAll(String status) throws SQLException {
        boolean filter = "ISSUED".equals(status) || "RETURNED".equals(status);
        String sql = "SELECT i.*, b.title, m.name AS member_name, "
                   + "CASE WHEN i.status='ISSUED' AND CURDATE() > i.due_date THEN DATEDIFF(CURDATE(), i.due_date) ELSE 0 END AS days_overdue "
                   + "FROM issues i JOIN books b ON b.id = i.book_id JOIN members m ON m.id = i.member_id "
                   + (filter ? "WHERE i.status = ? " : "") + "ORDER BY i.id DESC";
        List<IssueRecord> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            if (filter) ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    IssueRecord r = new IssueRecord();
                    r.setId(rs.getInt("id"));
                    r.setBookId(rs.getInt("book_id"));
                    r.setMemberId(rs.getInt("member_id"));
                    r.setBookTitle(rs.getString("title"));
                    r.setMemberName(rs.getString("member_name"));
                    r.setIssueDate(rs.getDate("issue_date"));
                    r.setDueDate(rs.getDate("due_date"));
                    r.setReturnDate(rs.getDate("return_date"));
                    r.setStatus(rs.getString("status"));
                    r.setDaysOverdue(rs.getInt("days_overdue"));
                    // returned -> stored fine ; issued & overdue -> running fine
                    r.setFine("RETURNED".equals(r.getStatus()) ? rs.getDouble("fine")
                                                              : r.getDaysOverdue() * (double) FINE_PER_DAY);
                    list.add(r);
                }
            }
        }
        return list;
    }

    /** Issue a book inside a transaction. */
    public void issueBook(int bookId, int memberId, int days) throws SQLException, LibraryException {
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                try (PreparedStatement ps = con.prepareStatement("SELECT available_copies FROM books WHERE id = ? FOR UPDATE")) {
                    ps.setInt(1, bookId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new LibraryException("Book not found.");
                        if (rs.getInt(1) <= 0) throw new LibraryException("No copies of this book are available.");
                    }
                }
                try (PreparedStatement ps = con.prepareStatement("SELECT status FROM members WHERE id = ?")) {
                    ps.setInt(1, memberId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new LibraryException("Member not found.");
                        if (!"ACTIVE".equals(rs.getString(1))) throw new LibraryException("Member is inactive.");
                    }
                }
                try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM issues WHERE member_id = ? AND status = 'ISSUED'")) {
                    ps.setInt(1, memberId);
                    try (ResultSet rs = ps.executeQuery()) {
                        rs.next();
                        if (rs.getInt(1) >= MAX_BOOKS_PER_MEMBER)
                            throw new LibraryException("Member already holds " + MAX_BOOKS_PER_MEMBER + " books (limit reached).");
                    }
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO issues (book_id, member_id, issue_date, due_date) VALUES (?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL ? DAY))")) {
                    ps.setInt(1, bookId);
                    ps.setInt(2, memberId);
                    ps.setInt(3, days);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = con.prepareStatement("UPDATE books SET available_copies = available_copies - 1 WHERE id = ?")) {
                    ps.setInt(1, bookId);
                    ps.executeUpdate();
                }
                con.commit();
            } catch (SQLException | LibraryException e) {
                con.rollback();
                throw e;
            }
        }
    }

    /** Return a book, calculate fine, restore stock. Returns the fine charged. */
    public double returnBook(int issueId) throws SQLException, LibraryException {
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                int bookId;
                double fine;
                String sql = "SELECT book_id, GREATEST(DATEDIFF(CURDATE(), due_date), 0) AS late FROM issues WHERE id = ? AND status = 'ISSUED' FOR UPDATE";
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, issueId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new LibraryException("Issue record not found or already returned.");
                        bookId = rs.getInt("book_id");
                        fine = rs.getInt("late") * (double) FINE_PER_DAY;
                    }
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE issues SET return_date = CURDATE(), fine = ?, status = 'RETURNED' WHERE id = ?")) {
                    ps.setDouble(1, fine);
                    ps.setInt(2, issueId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = con.prepareStatement("UPDATE books SET available_copies = available_copies + 1 WHERE id = ?")) {
                    ps.setInt(1, bookId);
                    ps.executeUpdate();
                }
                con.commit();
                return fine;
            } catch (SQLException | LibraryException e) {
                con.rollback();
                throw e;
            }
        }
    }

    /** Dashboard counters */
    public Map<String, Number> stats() throws SQLException {
        Map<String, Number> m = new LinkedHashMap<>();
        try (Connection con = DBConnection.getConnection(); Statement st = con.createStatement()) {
            m.put("titles", scalar(st, "SELECT COUNT(*) FROM books"));
            m.put("copies", scalar(st, "SELECT COALESCE(SUM(total_copies),0) FROM books"));
            m.put("available", scalar(st, "SELECT COALESCE(SUM(available_copies),0) FROM books"));
            m.put("members", scalar(st, "SELECT COUNT(*) FROM members WHERE status='ACTIVE'"));
            m.put("issued", scalar(st, "SELECT COUNT(*) FROM issues WHERE status='ISSUED'"));
            m.put("overdue", scalar(st, "SELECT COUNT(*) FROM issues WHERE status='ISSUED' AND due_date < CURDATE()"));
        }
        return m;
    }

    private int scalar(Statement st, String sql) throws SQLException {
        try (ResultSet rs = st.executeQuery(sql)) {
            rs.next();
            return rs.getInt(1);
        }
    }
}
