<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${empty book || book.id == 0 ? 'Add' : 'Edit'} Book - Library</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<c:set var="active" value="books"/>
<%@ include file="header.jspf" %>

<h2 class="page-title">${empty book || book.id == 0 ? 'Add New Book' : 'Edit Book'}</h2>
<div class="form-box">
  <form action="${pageContext.request.contextPath}/books" method="post" onsubmit="return validateBook();">
    <input type="hidden" name="action" value="save">
    <c:if test="${not empty book && book.id != 0}"><input type="hidden" name="id" value="${book.id}"></c:if>

    <label for="isbn">ISBN *</label>
    <input type="text" id="isbn" name="isbn" value="<c:out value='${book.isbn}'/>" placeholder="e.g. 9780132350884">
    <label for="title">Title *</label>
    <input type="text" id="title" name="title" value="<c:out value='${book.title}'/>">
    <div class="row">
      <div><label for="author">Author *</label>
        <input type="text" id="author" name="author" value="<c:out value='${book.author}'/>"></div>
      <div><label for="category">Category *</label>
        <input type="text" id="category" name="category" value="<c:out value='${book.category}'/>" list="cats">
        <datalist id="cats"><option>Programming</option><option>Computer Science</option><option>Database</option>
          <option>Fiction</option><option>Biography</option><option>Science</option><option>History</option></datalist></div>
    </div>
    <div class="row">
      <div><label for="publisher">Publisher</label>
        <input type="text" id="publisher" name="publisher" value="<c:out value='${book.publisher}'/>"></div>
      <div><label for="totalCopies">Total Copies *</label>
        <input type="number" id="totalCopies" name="totalCopies" min="1" max="999" value="${empty book ? 1 : book.totalCopies}"></div>
    </div>
    <div class="form-actions">
      <button class="btn" type="submit">Save Book</button>
      <a class="btn light" href="${pageContext.request.contextPath}/books">Cancel</a>
    </div>
  </form>
</div>
<script>
function validateBook() {
  var f = function(id) { return document.getElementById(id).value.trim(); };
  if (!f('isbn') || !f('title') || !f('author') || !f('category')) { alert('ISBN, title, author and category are required.'); return false; }
  if (!/^[0-9\-]{10,17}$/.test(f('isbn'))) { alert('ISBN must contain 10 to 17 digits (hyphens allowed).'); return false; }
  var n = parseInt(f('totalCopies'), 10);
  if (isNaN(n) || n < 1 || n > 999) { alert('Total copies must be between 1 and 999.'); return false; }
  return true;
}
</script>
<%@ include file="footer.jspf" %>
</body>
</html>
