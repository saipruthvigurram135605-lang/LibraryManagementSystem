<%@ page contentType="text/html;charset=UTF-8" language="java" isErrorPage="true" %>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Error</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"></head>
<body>
<div class="login-wrap" style="max-width:520px;text-align:center">
  <h2>Something went wrong</h2>
  <p class="sub">The page you requested could not be shown.</p>
  <a class="btn" style="display:block" href="${pageContext.request.contextPath}/dashboard">Back to Dashboard</a>
</div>
</body>
</html>
