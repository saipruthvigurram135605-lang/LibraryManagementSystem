<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${empty member || member.id == 0 ? 'Register' : 'Edit'} Member - Library</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<c:set var="active" value="members"/>
<%@ include file="header.jspf" %>

<h2 class="page-title">${empty member || member.id == 0 ? 'Register New Member' : 'Edit Member'}</h2>
<div class="form-box">
  <form action="${pageContext.request.contextPath}/members" method="post" onsubmit="return validateMember();">
    <input type="hidden" name="action" value="save">
    <c:if test="${not empty member && member.id != 0}"><input type="hidden" name="id" value="${member.id}"></c:if>

    <label for="name">Full Name *</label>
    <input type="text" id="name" name="name" value="<c:out value='${member.name}'/>">
    <div class="row">
      <div><label for="email">Email *</label>
        <input type="email" id="email" name="email" value="<c:out value='${member.email}'/>"></div>
      <div><label for="phone">Phone (10 digits) *</label>
        <input type="text" id="phone" name="phone" maxlength="10" value="<c:out value='${member.phone}'/>"></div>
    </div>
    <label for="address">Address</label>
    <textarea id="address" name="address" rows="3"><c:out value="${member.address}"/></textarea>
    <label for="status">Status</label>
    <select id="status" name="status">
      <option value="ACTIVE" ${member.status != 'INACTIVE' ? 'selected' : ''}>ACTIVE</option>
      <option value="INACTIVE" ${member.status == 'INACTIVE' ? 'selected' : ''}>INACTIVE</option>
    </select>
    <div class="form-actions">
      <button class="btn" type="submit">Save Member</button>
      <a class="btn light" href="${pageContext.request.contextPath}/members">Cancel</a>
    </div>
  </form>
</div>
<script>
function validateMember() {
  var f = function(id) { return document.getElementById(id).value.trim(); };
  if (!f('name') || !f('email') || !f('phone')) { alert('Name, email and phone are required.'); return false; }
  if (!/^[\w.+\-]+@[\w\-]+(\.[\w\-]+)+$/.test(f('email'))) { alert('Enter a valid email address.'); return false; }
  if (!/^[0-9]{10}$/.test(f('phone'))) { alert('Phone number must be exactly 10 digits.'); return false; }
  return true;
}
</script>
<%@ include file="footer.jspf" %>
</body>
</html>
