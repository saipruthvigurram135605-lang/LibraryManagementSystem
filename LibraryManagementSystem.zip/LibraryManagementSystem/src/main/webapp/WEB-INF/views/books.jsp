<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Books - Library</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<c:set var="active" value="books"/>
<%@ include file="header.jspf" %>

<h2 class="page-title">Books Catalogue</h2>
<div class="toolbar">
  <form action="${pageContext.request.contextPath}/books" method="get">
    <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Search title, author, ISBN, category" style="width:300px">
    <button class="btn" type="submit">Search</button>
    <a class="btn light" href="${pageContext.request.contextPath}/books">Reset</a>
  </form>
  <a class="btn gold" href="${pageContext.request.contextPath}/books?action=new">+ Add Book</a>
</div>

<table>
  <tr><th>#</th><th>ISBN</th><th>Title</th><th>Author</th><th>Category</th><th>Total</th><th>Available</th><th>Actions</th></tr>
  <c:forEach var="b" items="${books}" varStatus="st">
    <tr>
      <td>${st.count}</td>
      <td><c:out value="${b.isbn}"/></td>
      <td><c:out value="${b.title}"/></td>
      <td><c:out value="${b.author}"/></td>
      <td><c:out value="${b.category}"/></td>
      <td>${b.totalCopies}</td>
      <td><span class="badge ${b.availableCopies > 0 ? 'green' : 'red'}">${b.availableCopies}</span></td>
      <td>
        <a class="btn sm" href="${pageContext.request.contextPath}/books?action=edit&id=${b.id}">Edit</a>
        <form class="inline" action="${pageContext.request.contextPath}/books" method="post"
              onsubmit="return confirm('Delete this book permanently?');">
          <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="${b.id}">
          <button class="btn sm red" type="submit">Delete</button>
        </form>
      </td>
    </tr>
  </c:forEach>
  <c:if test="${empty books}"><tr><td colspan="8" class="empty">No books found.</td></tr></c:if>
</table>
<%@ include file="footer.jspf" %>
</body>
</html>
