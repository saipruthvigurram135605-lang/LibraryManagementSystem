<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Members - Library</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<c:set var="active" value="members"/>
<%@ include file="header.jspf" %>

<h2 class="page-title">Library Members</h2>
<div class="toolbar">
  <form action="${pageContext.request.contextPath}/members" method="get">
    <input type="text" name="q" value="<c:out value='${q}'/>" placeholder="Search name, email, phone, member ID" style="width:300px">
    <button class="btn" type="submit">Search</button>
    <a class="btn light" href="${pageContext.request.contextPath}/members">Reset</a>
  </form>
  <a class="btn gold" href="${pageContext.request.contextPath}/members?action=new">+ Register Member</a>
</div>

<table>
  <tr><th>Member ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th><th>Status</th><th>Actions</th></tr>
  <c:forEach var="m" items="${members}">
    <tr>
      <td>${m.memberCode}</td>
      <td><c:out value="${m.name}"/></td>
      <td><c:out value="${m.email}"/></td>
      <td><c:out value="${m.phone}"/></td>
      <td><fmt:formatDate value="${m.joinedDate}" pattern="dd-MM-yyyy"/></td>
      <td><span class="badge ${m.status == 'ACTIVE' ? 'green' : 'grey'}">${m.status}</span></td>
      <td>
        <a class="btn sm" href="${pageContext.request.contextPath}/members?action=edit&id=${m.id}">Edit</a>
        <form class="inline" action="${pageContext.request.contextPath}/members" method="post"
              onsubmit="return confirm('Delete this member permanently?');">
          <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="${m.id}">
          <button class="btn sm red" type="submit">Delete</button>
        </form>
      </td>
    </tr>
  </c:forEach>
  <c:if test="${empty members}"><tr><td colspan="7" class="empty">No members found.</td></tr></c:if>
</table>
<%@ include file="footer.jspf" %>
</body>
</html>
