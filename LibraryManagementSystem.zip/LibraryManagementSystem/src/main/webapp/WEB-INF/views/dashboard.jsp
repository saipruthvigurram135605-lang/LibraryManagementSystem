<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard - Library</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<c:set var="active" value="dashboard"/>
<%@ include file="header.jspf" %>

<h2 class="page-title">Dashboard</h2>
<div class="cards">
  <div class="card"><div class="num">${stats.titles}</div><div class="lbl">Book Titles</div></div>
  <div class="card"><div class="num">${stats.copies}</div><div class="lbl">Total Copies</div></div>
  <div class="card ok"><div class="num">${stats.available}</div><div class="lbl">Available</div></div>
  <div class="card"><div class="num">${stats.members}</div><div class="lbl">Active Members</div></div>
  <div class="card"><div class="num">${stats.issued}</div><div class="lbl">Books Issued</div></div>
  <div class="card warn"><div class="num">${stats.overdue}</div><div class="lbl">Overdue</div></div>
</div>

<div class="panel">
  <h3>Quick Actions</h3>
  <a class="btn" href="${pageContext.request.contextPath}/issues">Issue / Return Book</a>
  <a class="btn gold" href="${pageContext.request.contextPath}/books?action=new">Add New Book</a>
  <a class="btn gold" href="${pageContext.request.contextPath}/members?action=new">Register Member</a>
</div>

<div class="panel">
  <h3>Recently Issued Books (currently out)</h3>
  <table>
    <tr><th>Book</th><th>Member</th><th>Issued On</th><th>Due Date</th><th>Status</th></tr>
    <c:forEach var="r" items="${recent}">
      <tr>
        <td><c:out value="${r.bookTitle}"/></td>
        <td><c:out value="${r.memberName}"/></td>
        <td><fmt:formatDate value="${r.issueDate}" pattern="dd-MM-yyyy"/></td>
        <td><fmt:formatDate value="${r.dueDate}" pattern="dd-MM-yyyy"/></td>
        <td><c:choose>
              <c:when test="${r.daysOverdue > 0}"><span class="badge red">Overdue ${r.daysOverdue}d</span></c:when>
              <c:otherwise><span class="badge blue">Issued</span></c:otherwise>
            </c:choose></td>
      </tr>
    </c:forEach>
    <c:if test="${empty recent}"><tr><td colspan="5" class="empty">No books are currently issued.</td></tr></c:if>
  </table>
</div>
<%@ include file="footer.jspf" %>
</body>
</html>
