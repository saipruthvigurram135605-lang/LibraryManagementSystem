<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Issue / Return - Library</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<c:set var="active" value="issues"/>
<%@ include file="header.jspf" %>

<h2 class="page-title">Issue / Return Books</h2>

<div class="panel">
  <h3>Issue a Book</h3>
  <form action="${pageContext.request.contextPath}/issues" method="post" onsubmit="return validateIssue();">
    <input type="hidden" name="action" value="issue">
    <div class="row">
      <div><label for="bookId">Book (available only)</label>
        <select id="bookId" name="bookId">
          <option value="">-- Select book --</option>
          <c:forEach var="b" items="${books}">
            <option value="${b.id}"><c:out value="${b.title}"/> &mdash; <c:out value="${b.author}"/> (${b.availableCopies} left)</option>
          </c:forEach>
        </select></div>
      <div><label for="memberId">Member (active only)</label>
        <select id="memberId" name="memberId">
          <option value="">-- Select member --</option>
          <c:forEach var="m" items="${members}">
            <option value="${m.id}">${m.memberCode} &mdash; <c:out value="${m.name}"/></option>
          </c:forEach>
        </select></div>
      <div><label for="days">Loan period (days)</label>
        <input type="number" id="days" name="days" value="14" min="1" max="30"></div>
    </div>
    <div class="form-actions"><button class="btn" type="submit">Issue Book</button>
      <span style="font-size:13px;color:#777;margin-left:10px">Late fine: Rs. ${finePerDay} per day. Max 3 books per member.</span></div>
  </form>
</div>

<div class="toolbar">
  <div>
    <a class="btn ${status == 'ISSUED' ? '' : 'light'}" href="${pageContext.request.contextPath}/issues?status=ISSUED">Currently Issued</a>
    <a class="btn ${status == 'RETURNED' ? '' : 'light'}" href="${pageContext.request.contextPath}/issues?status=RETURNED">Returned</a>
    <a class="btn ${status == 'ALL' ? '' : 'light'}" href="${pageContext.request.contextPath}/issues?status=ALL">All Records</a>
  </div>
</div>

<table>
  <tr><th>ID</th><th>Book</th><th>Member</th><th>Issued</th><th>Due</th><th>Returned</th><th>Fine (Rs.)</th><th>Status</th><th>Action</th></tr>
  <c:forEach var="r" items="${issues}">
    <tr>
      <td>${r.id}</td>
      <td><c:out value="${r.bookTitle}"/></td>
      <td><c:out value="${r.memberName}"/></td>
      <td><fmt:formatDate value="${r.issueDate}" pattern="dd-MM-yyyy"/></td>
      <td><fmt:formatDate value="${r.dueDate}" pattern="dd-MM-yyyy"/></td>
      <td><c:choose><c:when test="${not empty r.returnDate}"><fmt:formatDate value="${r.returnDate}" pattern="dd-MM-yyyy"/></c:when><c:otherwise>&mdash;</c:otherwise></c:choose></td>
      <td><fmt:formatNumber value="${r.fine}" maxFractionDigits="0"/></td>
      <td><c:choose>
            <c:when test="${r.status == 'RETURNED'}"><span class="badge green">Returned</span></c:when>
            <c:when test="${r.daysOverdue > 0}"><span class="badge red">Overdue ${r.daysOverdue}d</span></c:when>
            <c:otherwise><span class="badge blue">Issued</span></c:otherwise>
          </c:choose></td>
      <td>
        <c:if test="${r.status == 'ISSUED'}">
          <form class="inline" action="${pageContext.request.contextPath}/issues" method="post"
                onsubmit="return confirm('Mark this book as returned?');">
            <input type="hidden" name="action" value="return"><input type="hidden" name="id" value="${r.id}">
            <button class="btn sm gold" type="submit">Return</button>
          </form>
        </c:if>
      </td>
    </tr>
  </c:forEach>
  <c:if test="${empty issues}"><tr><td colspan="9" class="empty">No records found.</td></tr></c:if>
</table>
<script>
function validateIssue() {
  if (!document.getElementById('bookId').value) { alert('Please select a book.'); return false; }
  if (!document.getElementById('memberId').value) { alert('Please select a member.'); return false; }
  var d = parseInt(document.getElementById('days').value, 10);
  if (isNaN(d) || d < 1 || d > 30) { alert('Loan period must be between 1 and 30 days.'); return false; }
  return true;
}
</script>
<%@ include file="footer.jspf" %>
</body>
</html>
