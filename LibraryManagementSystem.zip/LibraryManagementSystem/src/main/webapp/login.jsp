<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login - Library Management System</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<div class="login-wrap">
  <h2>&#128218; City Central Library</h2>
  <p class="sub">Library Management System &mdash; Staff Login</p>
  <c:if test="${not empty error}"><div class="alert error"><c:out value="${error}"/></div></c:if>
  <form action="${pageContext.request.contextPath}/login" method="post" onsubmit="return validateLogin();">
    <label for="username">Username</label>
    <input type="text" id="username" name="username" value="<c:out value='${username}'/>" autofocus>
    <label for="password">Password</label>
    <input type="password" id="password" name="password">
    <button type="submit" class="btn">Login</button>
  </form>
  <div class="hint">Demo: admin / admin123 &nbsp;|&nbsp; librarian / lib123</div>
</div>
<script>
function validateLogin() {
  var u = document.getElementById('username').value.trim();
  var p = document.getElementById('password').value;
  if (u === '' || p === '') { alert('Please enter username and password.'); return false; }
  return true;
}
</script>
</body>
</html>
